// let age = prompt("Сколько тебе лет?");
//  if(age<17){
//     document.write("Привет малыш!");
// } else if (age<25){
//     document.write("Привет!");
// }else if (age<100){
//     document.write("Здавствуйте!");
// } else {
//     document.write("О, какой необычный возраст");
// }

// #упр
//#1
/*let lang = prompt("Какой язык вы выбираете 'ru' или 'ky'?");
 if(lang==='ru'){
     document.write("Здравствуйте!");
 } else if(lang==='ky'){
     document.write("Саламатсызбы!");
 } else {
     document.write("Мы не знаем такого языка" );
 }*/

 //#2
//  let a = 'abcde';
//  let b = 'bcdef';
//  if(a[0]==='a'){
//      document.write("yes");
//  } else {
//      document.write("no");
//  }

//#3
//let number = 12345;
/*let number = 34215;
if (number[0]==='1'){
    document.write("yes");
} else {
    document.write("no");
}*/

//Самостоятельная работа 
//1

/*let numb = prompt("Введите число?");
if (numb % 2 === 0){
    document.write("Четное число");
} else{
    document.write("Нечетное число");
}*/

//2

/*let month = prompt("Какое сейчас месяц?");
if (month === 'январь'){
    alert(`${month} - Зима`)
} else if (month === 'февраль'){
    alert(`${month} - Зима`)
} else if (month === 'декабрь'){
    alert(`${month} - Зима`)
} else if (month === 'март'){
    alert(`${month} - Весна`)
} else if (month === 'апрель'){
    alert(`${month} - Весна`)
} else if (month === 'май'){
    alert(`${month} - Весна`)
} else if (month === 'июнь'){
    alert(`${month} - Лето`)
} else if (month === 'июль'){
    alert(`${month} - Лето`)
} else if (month === 'август'){
    alert(`${month} - Лето`)
} else if (month ==='сентябрь'){
    alert(`${month} - Осень`)
} else if (month === 'октябрь'){
    alert(`${month} - Осень`)
} else if (month === 'ноябрь'){
    alert(`${month} - Осень`)
} else {
    alert("Месяц введен неправильно")
}*/

//3

let year = prompt("Ваш год рождения?");
let cycle = 12
if (year % cycle === 0){
    document.write("Ваш знак зодиака по китайскому гороскопу: Обезьяна")
} else if (year % cycle === 1){
    document.write("Ваш знак зодиака по китайскому гороскопу: Петух")
} else if (year % cycle === 2){
    document.write("Ваш знак зодиака по китайскому гороскопу: Собака")
} else if (year % cycle === 3){
    document.write("Ваш знак зодиака по китайскому гороскопу: Кабан")
} else if (year % cycle === 4){
    document.write("Ваш знак зодиака по китайскому гороскопу: Крыса")
} else if (year % cycle === 5){
    document.write("Ваш знак зодиака по китайскому гороскопу: Бык")
} else if (year % cycle === 6){
    document.write("Ваш знак зодиака по китайскому гороскопу: Тигр")
} else if (year % cycle === 7){
    document.write("Ваш знак зодиака по китайскому гороскопу: Кролик")
} else if (year % cycle === 8){
    document.write("Ваш знак зодиака по китайскому гороскопу: Дракон")
} else if (year % cycle ===9){
    document.write("Ваш знак зодиака по китайскому гороскопу: Змея")
} else if (year % cycle === 10){
    document.write("Ваш знак зодиака по китайскому гороскопу: Лошадь")
} else if (year % cycle === 11){
    document.write("Ваш знак зодиака по китайскому гороскопу: Коза")
} else {
    document.write("Год введен неправильно")
}

